﻿

CREATE TABLE [dbo].[GEN_Login_Details] (
    [Id]        INT        IDENTITY (1, 1) NOT NULL,
    [Username]  NCHAR (20) NULL,
    [Password]  NCHAR (10) NULL,
    [User_Type] INT        NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

