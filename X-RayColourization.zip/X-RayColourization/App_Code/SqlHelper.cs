﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
using System.Data;
using Microsoft.ApplicationBlocks.Data;


public class SqlHelp
{
    public int ExecuteNonQuery1(string str)
    {
        string con = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection mycon = new SqlConnection(con);
        SqlCommand cmd = new SqlCommand(str, mycon);
        int result = 0;
        try
        {
            mycon.Open();
            result = cmd.ExecuteNonQuery();
            mycon.Close();
        }
        catch (Exception ex)
        {
            result = -1;
            try
            {
                if (mycon.State == ConnectionState.Open)
                {
                    mycon.Close();
                }
            }
            catch (Exception ex2)
            {

            }

        }
        return result;
    }
    public SqlDataReader GetReaderQuery(string str)
    {
        string con = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection myco = new SqlConnection(con);
        SqlCommand cmd = new SqlCommand(str, myco);
        SqlDataReader dr;
        int x;
        try
        {
            myco.Open();
            dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }
        catch (Exception ex)
        {
            return null;
        }
        return dr;
    }

    public Object ExecuteScalarQuery(string str)
    {
        string con = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection conc = new SqlConnection(con);
        SqlCommand cmd = new SqlCommand(str, conc);
        Object result = null;
        try
        {
            conc.Open();
            result = cmd.ExecuteScalar();
        }
        catch (Exception ex)
        {
            if (conc.State == ConnectionState.Open)
                conc.Close();
        }
        finally
        {
            if (conc.State == ConnectionState.Open)
                conc.Close();
        }
        return result;

    }
    public DataTable GetDataTable(string str)
    {
        string con = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        SqlConnection myco = new SqlConnection(con);
        SqlCommand cmd = new SqlCommand(str, myco);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        SqlCommandBuilder cb = new SqlCommandBuilder(da);
        DataSet ds = new DataSet();
        da.Fill(ds, "Records");
        DataTable dt;
        int x;
        try
        {
            myco.Open();
            dt = ds.Tables["Records"];
        }
        catch (Exception ex)
        {
            return null;
        }
        return dt;
    }
    public DataSet bindDataSet(string qry, List<SqlParameter> parm)
    {
        DataSet ds = new DataSet();
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        ds = SqlHelper.ExecuteDataset(constr, CommandType.Text, qry, parm.ToArray());
        return ds;
    }
    public int insertnew(string qry, List<SqlParameter> parm)
    {
        int result = 0;
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        result = SqlHelper.ExecuteNonQuery(constr, CommandType.Text, qry, parm.ToArray());
        return result;
    }
}


    
