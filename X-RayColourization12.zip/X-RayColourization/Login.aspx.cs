﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// 
/// </summary>
public partial class Login : System.Web.UI.Page
{
    SqlHelp sql = new SqlHelp();

    /// <summary>
    /// page load method
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">event argument e</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        H1.Visible = true;
    }
    /// <summary>
    /// login click event
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnLogin_Click(object sender, EventArgs e)
    {





        int id = Convert.ToInt32(sql.ExecuteScalarQuery("Select COUNT (*) from GEN_Login_Details where Username = '" + txtUsername.Text + "' and Password='" + txtPassword.Text +"'" ));
        if (id == 1)
        {
            SqlDataReader d = sql.GetReaderQuery("Select * from GEN_Login_Details where Username = '" + txtUsername.Text + "' and Password='" + txtPassword.Text + "'");
            while (d.Read())
            {
                Session["Username"] = d["Username"].ToString();
                
            }
            Response.Redirect("Welcome.aspx");
        }
        else
        {
            tr2.Visible = true;
            H1.Visible = true;
            H1.InnerText = "Invalid Username or Password.";
        }
    }
}